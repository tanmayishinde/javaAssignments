package com.ems.entity;
//encapsulation
public class Student {
    private int StudentID;
    private String Sfname;
    private String Slname;


    public int getStudentID() {
        return StudentID;
    }

    public void setStudentID(int studentID) {
        StudentID = studentID;
    }

    public String getSfname() {
        return Sfname;
    }

    public void setSfname(String sfname) {
        Sfname = sfname;
    }

    public String getSlname() {
        return Slname;
    }

    public void setSlname(String slname) {
        Slname = slname;
    }
}
