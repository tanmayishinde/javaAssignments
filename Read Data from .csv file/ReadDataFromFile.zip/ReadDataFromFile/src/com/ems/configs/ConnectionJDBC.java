package com.ems.configs;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionJDBC {
    public static Connection CreateConnection(){
        Connection con=null;
        try
        {
            //1.Create Connection using DriverManager.
            String dbURL = "jdbc:mysql://localHost:3306/student_demojdbc";
            String user = "root";
            String pass = "tanu1234";
            con = DriverManager.getConnection(dbURL, user, pass);

            //System.out.println("Db Connected!");


        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        return con;
    }
}

