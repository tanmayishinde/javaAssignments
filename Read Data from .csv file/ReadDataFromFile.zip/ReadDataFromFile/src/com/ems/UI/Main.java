package com.ems.UI;

import com.ems.operations.DataOperations;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        DataOperations dataOperations = new DataOperations();
        int ch;

        do {
            System.out.println("Read/Write Data from csv:");
            System.out.println("Enter the choice");
            System.out.println("Press 1 for Reading Data from CSV");
            System.out.println("Press 2 for Inserting data to DB");


            System.out.println("Press 4 to Exit App");

             ch = sc.nextInt();
            switch (ch) {
                case 1:
                    dataOperations.ReadDataCSV();
                    break;
                case 2:
                    dataOperations.InsertDataCSV();
                    break;
                case 0:
                    break;

            }
        }
        while (ch != 4);
    }







}

