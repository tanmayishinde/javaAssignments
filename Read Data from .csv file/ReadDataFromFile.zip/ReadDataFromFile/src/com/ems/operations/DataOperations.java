package com.ems.operations;

import com.ems.configs.ConnectionJDBC;
import com.ems.entity.Student;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Statement;

public class DataOperations {
    public  void ReadDataCSV(){
        String file = "src\\Student_Data.csv";
        BufferedReader reader = null;
        String line = "";


        try {

            reader = new BufferedReader(new FileReader(file));
            //Check to read next Line
            while ((line = reader.readLine()) != null) {
                //Array of strings seperated by commas
                String[] row = line.split(",");

                for (String index : row) {
                    //10 spaces of room for each string
                    System.out.printf("%-10s", index);

                }
                System.out.println();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                //Close the scanner
                reader.close();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }


    public  void InsertDataCSV(){
        String file = "src\\Student_Data.csv";
        BufferedReader reader = null;
        String line = "";

        Connection connsave = ConnectionJDBC.CreateConnection();
        try {

            reader = new BufferedReader(new FileReader(file));

            //Check to read next Line
            while ((line = reader.readLine()) != null) {
                //Array of strings seperated by commas
                String[] row = line.split(",");

                Student s = new Student();
                s.setStudentID(Integer.parseInt(row[0]));
                s.setSfname(row[1]);
                s.setSlname(row[2]);
                String query = "insert into student (StudentID,Sfname,Slname) values(" +s.getStudentID()+",'"+s.getSfname()+"','"+s.getSlname()+"')";
                Statement statement = connsave.createStatement();
                int i = statement.executeUpdate(query);
                if (i > 0) {
                    System.out.println("ROW INSERTED");
                } else {
                    System.out.println("ROW NOT INSERTED");
                }


                System.out.println();

            }
            connsave.close();
        }

        catch (Exception e) {
            e.printStackTrace();
        }

    }
}
